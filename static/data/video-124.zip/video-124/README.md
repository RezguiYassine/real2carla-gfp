# Video 124: Real2CARLA-GFP scene

A reconstruction of one real accident from the CADP videos, as Real2CARLA-GFP
produced it for the paper (review iteration 6, rated good). Time 0 is the
first contact. CARLA version: 0.9.16. Map: Town03.

## Files

- `scenario.json`: the scenario a person confirmed for this video (schema 2):
  road layout, how each road user arrives and moves, the collision (type,
  striker, struck side, where), traffic. Values marked `unknown` were left to
  the pipeline's defaults.
- `reconstruction.json`: what GFP estimated from one frame of the video.
  `pose`: pitch_deg, roll_deg, fov_deg, height_m of the real camera.
  `capability_tier` and `position_uncertainty_m`: GFP's own estimate of its
  position error. `collision.frame`: the contact frame in the real clip.
  `camera`: the near-real CARLA camera.
- `vehicle_<id>.csv`: the trajectory GFP measured for each crash-pair road
  user. Columns: `t_s` (s, 0 = contact), `frame` (real-video frame),
  `x_m, y_m, z_m` (CARLA world metres), `heading_deg`, `speed_ms` (m/s),
  `s_to_collision_m` (distance along the path to the contact point).
- `agents.csv`: every road user the simulation drives over [-8 s, +6 s],
  including traffic and the history invented before the vehicle was seen.
  Columns: `track_id, t, x, y, z, yaw, speed, source, class, involved,
  placement, confidence, ...`.
- `scene.json`: how the scene was built (map, window, agents by class, what
  was placed, cleaned or dropped).
- `collision.json`: the collision solver's plan for the crash pair (timing,
  sideways and speed changes) and its verification under CARLA physics.
- `recording.log`: CARLA recorder log of the rendered run. Replay it in CARLA
  0.9.16 with your own sensors:

      client.load_world("Town03")
      client.replay_file("/absolute/path/recording.log", 0, 0, 0)

  Scale caveat: absolute distances and speeds depend on the estimated camera
  height and are uncertain by tens of percent; the lane, manoeuvre, event
  order and collision geometry are the reliable parts.

License of the scene files: CC BY 4.0. The real video is from the CADP
dataset and is not included.
